document.addEventListener("DOMContentLoaded", function(){

    const switchBtn = document.getElementById("themeSwitch");

    function applyTheme(theme){
        if(theme === "dark"){
            document.body.classList.add("dark");
            switchBtn.checked = true;
        }else{
            document.body.classList.remove("dark");
            switchBtn.checked = false;
        }
    }

    // load awal
    const savedTheme = localStorage.getItem("theme") || "light";
    applyTheme(savedTheme);

    // toggle
    window.toggleTheme = function(){
        const isDark = switchBtn.checked;

        if(isDark){
            document.body.classList.add("dark");
            localStorage.setItem("theme","dark");
        }else{
            document.body.classList.remove("dark");
            localStorage.setItem("theme","light");
        }
    }

});